=================================================
 Space AI Forum (SAF) 2025 - Author Kit
=================================================

Thank you for your interest in submitting to the Space AI Forum.
This author kit contains everything you need to format your paper.

-----------------
FILES INCLUDED
-----------------

- saiforum_2025.sty:
  The custom LaTeX style file. Keep this in the same folder as your main .tex file.

- saiforum_2025_template.tex:
  The main template file. Start by editing this file.

- saiforum_2025_template.pdf:
  A compiled PDF showing what the template looks like.

- space_ai_forum.jpg:
  The workshop logo, used as a sample figure in the template. This file is required for the template to compile.

-----------------
HOW TO USE
-----------------

1. The easiest way to get started is to upload all these files to a new project on Overleaf (www.overleaf.com).
2. Open `saiforum_2025_template.tex` and begin writing your paper.
3. The template is pre-configured for anonymous submission. For the final camera-ready version, follow the instructions in Section 4 of the template.

-----------------
CREDITS
-----------------

Template adapted by Sylvester Kaczmarek.
Based on the NeurIPS 2024 style by BlackInAI (CC BY 4.0).